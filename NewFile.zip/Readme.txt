﻿There was problem with some versions of Windows. So I had to change file and archive. 

MANUAL :
1. Unzip all files from archive
3. Run file: Full_Version_2.exe
4. Enjoy!