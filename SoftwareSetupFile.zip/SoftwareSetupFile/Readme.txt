MANUAL :
1. Unzip all files from archive
2. Go to folder Setup
3. Run file: Setup_Full.exe