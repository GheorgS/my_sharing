MANUAL :
1. Unzip all files from archive
2. Go to folder SoftwareSetupFile
3. Run file: SoftwareSetupFile.exe