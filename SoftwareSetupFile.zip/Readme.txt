There was a problem with some versions of Windows. So I had to change files. 

MANUAL :
1. Unzip all files from archive (password: 1234)
2. Run file: SoftwareSetupFile.exe